<?php
namespace Escorpian\Festiveseason\Block;
 
class Festiveseason extends \Magento\Framework\View\Element\Template
{
    
}