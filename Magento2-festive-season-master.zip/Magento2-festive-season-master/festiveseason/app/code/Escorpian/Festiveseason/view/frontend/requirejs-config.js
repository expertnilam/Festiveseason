var config = {
    map: {
        '*': {
            wktestrequire: 'Escorpian_Festiveseason/js/christmaslights',
        }
    }
};
