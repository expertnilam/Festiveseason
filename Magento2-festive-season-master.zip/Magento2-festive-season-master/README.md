# Magento2 Festive Season Extension

We are glad to release a Festive Season Extension in Magento 2, which will helps for making your online store look drenched with festive fervour. 
It will allow you offer your customers the most existing festival shopping experience with unique decoration and freshness in your store.

You can create decorate your by giving new effects and styling. It will attract your visitors and customers to stop by to rejoice the awesome look and feel of your store and feel the festival zest.
